import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Tasks } from './components/index/Tasks';

@Injectable({
  providedIn: 'root'
})
export class TasksService {

  uri = 'http://localhost:4000/tm';
  
    constructor(private http: HttpClient) { }
  
    addTaskRecord(task,priority,start_date,end_date) {
      const obj = {
        task: task,
        //parent_id : parent_id,
        priority: priority,
        start_date : start_date,
        end_date : end_date
      };
      this.http.post(`${this.uri}/add`, obj)
          .subscribe(res => console.log('Done'));
    }

      getAllTasks() 
      {
        return this.http.get(`${this.uri}/`);
      }

      getTaskByID(id) 
      {
        return this.http.get(`${this.uri}/edit/${id}`);
      }

      updateRecord(task,priority,start_date,end_date, id)
      {
          const obj = {
          task: task,
          priority: priority,
          start_date : start_date,
          end_date : end_date
          };
          this
          .http
          .post(`${this.uri}/update/${id}`, obj)
          .subscribe(res => console.log('Done'));
      }

      deleteRecord(id) 
      {
        return this
                  .http
                  .get(`${this.uri}/delete/${id}`);
      }
}
