import { Component, OnInit } from '@angular/core';
import { Tasks } from './Tasks';
import { TasksService } from '../../tasks.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  tasksResult : Tasks[];
  
    constructor(private tasksservice: TasksService) { }
  
    ngOnInit() {
      this.findalltask(); 
    }

    findalltask()
    {
      this.tasksservice
      .getAllTasks()
      .subscribe((data: Tasks[]) => {
      this.tasksResult = data;
    });
    }

    deleteTask(id) {
      this.tasksservice.deleteRecord(id).subscribe(res => {
        console.log('Deleted');
      });
    }
}
