import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { TasksService } from '../../tasks.service';


@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  constructor(private tasksservice: TasksService, private fb: FormBuilder) { this.createForm(); }

  addTaskForm: FormGroup;
  

  createForm() {
    this.addTaskForm = this.fb.group({
      task: ['', Validators.required ],
      priority : ['', Validators.required ],
      start_date: ['', Validators.required ],
      end_date: ['', Validators.required ],
      
   });
  }

  addTask(task,priority,start_date,end_date) {
    this.tasksservice.addTaskRecord(task,priority,start_date,end_date);
  }

  ngOnInit() {
    
  }

}
