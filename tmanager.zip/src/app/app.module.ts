import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';



// import 3rd party modules -- ++ imports
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

// import component -- ++ in Declaration
import { AppComponent } from './app.component';
import { CreateComponent } from './components/create/create.component';
import { IndexComponent } from './components/index/index.component';
import { EditComponent } from './components/edit/edit.component';

//import service -- ++ in provider
import { TasksService } from './tasks.service';

const routes: Routes = [
  {path:'create', component :CreateComponent},
  {path:'index', component :IndexComponent},
  {path:'edit/:id', component :EditComponent},
  { path: '', redirectTo: '/create', pathMatch: 'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    IndexComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [TasksService],
  bootstrap: [AppComponent]
})
export class AppModule { }
